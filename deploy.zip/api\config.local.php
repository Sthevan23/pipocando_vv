<?php
/**
 * Credenciais MySQL — Hostinger (pipocandovv.com.br)
 * NÃO envie este arquivo para o GitHub com a senha real.
 */
return [
  'host' => 'localhost',
  'port' => 3306,
  'name' => 'u586160337_pipocandovv',
  'user' => 'u586160337_pipocandovv',
  'pass' => 'Sh100901',
  'charset' => 'utf8mb4',
];
